<html>
<!-------------script and css files-------------------->
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Lato:300,400,700'>
<style>
  body {
  padding: 20px 0;
  font-family: Lato, sans-serif;
}
</style>
<!-- ---------------css part end------- -->
<div class="container">  
  <form id="category_form" method="post" action="" role="form">
    <div class="field_wrapper">
      <div class="row">
        <div class="col-md-2">
          <div class="form-group">
              <label for="form_name">Name </label>
              <input id="name" type="text" name="name[]" class="form-control" placeholder="Name" required="required">
          </div>
        </div>
        <div class="col-md-2">
          <div class="form-group">
              <label for="form_lastname">Quantity </label>
              <input id="quantity" type="text" name="quantity[]" class="form-control" placeholder="Quantity" required="required" >
          </div>
        </div>
        <div class="col-md-2">
          <div class="form-group">
              <label for="form_lastname">Unit Price </label>
              <input id="unitprice" type="text" name="unitprice[]" class="form-control" placeholder="Unit Price" required="required">
          </div>
        </div>
        <div class="col-md-2">
          <div class="form-group">
              <label for="form_lastname">Tax </label>
              <select id="tax"  name="tax[]" class="form-control" style="height: 34px;">
                  <option value="">--Select--</option>
                  <option value="0">0%</option>
                  <option value="1">1%</option>
                  <option value="5">5%</option>
                  <option value="10">10%</option>
              </select>
          </div>
        </div>
        <div class="col-md-2">
          <div class="form-group">
              <label for="form_lastname"></label>
              <br><br><a href="javascript:void(0);" class="add_button" title="Add field"><img src="https://img.icons8.com/ios-glyphs/30/000000/plus.png" height="18px"/></a>
          </div>
        </div>
      </div>
    </div>
    <div class="form-group">
        <button type="button" id="add_item" class="btn btn-fill btn-info">ADD</button>
    </div>
  </form>
</div>
<!---------- Script Section ------- -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){

    var maxField = 10; 
    var addButton = $('.add_button'); 
    var wrapper = $('.field_wrapper'); 
    var x = 1; //Initial field counter is 1
    var fieldHTML='<div class="row"><div class="col-md-2"><div class="form-group"><label for="form_name"></label><input id="name" type="text" name="name[]" class="form-control" placeholder="Name" required="required"></div></div>';
    fieldHTML+='<div class="col-md-2"><div class="form-group"><label for="form_lastname"> </label><input id="quantity" type="text" name="quantity[]" class="form-control" placeholder="Quantity" required="required"></div></div>';
    fieldHTML+='<div class="col-md-2"><div class="form-group"><label for="form_lastname"></label><input id="unitprice" type="text" name="unitprice[]" class="form-control" placeholder="Unit Price" required="required" data-error="Lastname is required."></div></div>';
    fieldHTML+='<div class="col-md-2"><div class="form-group"><label for="form_lastname"></label><select id="tax" name="tax[]" class="form-control" style="height:34px;"><option value="">--Select--</option><option value="0">0%</option><option value="1">1%</option><option value="5">5%</option><option value="10">10%</option></select></div></div>';
    fieldHTML+='<div class="col-md-2 remove_button"><div class="form-group"><label for="form_lastname"></label><a href="javascript:void(0);" ><img src="https://img.icons8.com/ios-glyphs/30/000000/filled-trash.png" height="18px"/></a></div></div></div>';

    //Once add button is clicked
    $(addButton).click(function(){
        //Check maximum number of input fields
        if(x < maxField){ 
            x++; //Increment field counter
            $(wrapper).append(fieldHTML); //Add field html
        }
    });
    
    //Once remove button is clicked
    $(wrapper).on('click', '.remove_button', function(e){
        e.preventDefault();
        $(this).parent('div').remove(); //Remove field html
        x--; //Decrement field counter
    });

// function to add items
    $("#add_item").click(function(){
        var formdata_ser = $("#category_form").serialize();
        $.ajax({
          url: '<?php echo base_url();?>Add-item',
          type: 'post',
          data: formdata_ser,
          dataType: 'json',
          success: function(responseData){
            if(responseData.status==1){
              window.location = '<?php echo base_url();?>View-cart';
            }
            else{
              alert(responseData.msg);
            }
            
          }
        });
    });
});

</script>