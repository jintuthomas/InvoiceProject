
<!DOCTYPE html>
<html>
<head>
  <title>Invoice</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<style type="text/css">
  .table td, .table th {
    padding: 0.5rem;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
    font-size: 14px;
}
</style>
</head>
<body>
  
<div class="container mt-3">
  <div class="row justify-content-center">
    <div class="col-8">
      <div class="card">
        <div class="card-body">
          <h3 class="text-center font-weight-bold mb-1">Demo Billing</h3>
          <p class="text-center font-weight-bold mb-0">GSTIN No.: 09AANFB4888NIZH</p>
          <p class="text-center font-weight-bold"><small class="font-weight-bold">Phone No.: 0120-4571570/7042344100</small></p>
          <div class="row pb-2 p-2">
            <div class="col-md-6">
              <p class="mb-0"><strong>Invoice Number</strong>: IN0010012804</p>
              <p><strong>Name</strong>: IN0010012804</p>            
            </div>
            <div class="col-md-6 text-right">
              <p class="mb-0"><strong>Invoice Date</strong>: <?php echo date("d-M-Y")?> </p>
              <p><strong>Phone</strong>: 9643208548</p>
            </div>
          </div>
          <div class="table-responsive">
            <table class="table table-bordered mb-0">
              <thead>
                <tr>
                  <th class="text-uppercase small font-weight-bold">SR No.</th>
                  <th class="text-uppercase small font-weight-bold">Item Name</th>
                  <th class="text-uppercase small font-weight-bold">Qty</th>
                  <th class="text-uppercase small font-weight-bold">Unit Price</th>
                  <th class="text-uppercase small font-weight-bold">Tax %</th>
                  <th class="text-uppercase small font-weight-bold">Tax Amt.</th>
                  <th class="text-uppercase small font-weight-bold">Total</th>
                </tr>
              </thead>
              <tbody>
              <?php  
                $slno=1;
                $sum=0;
              ?>
              <?php
                  foreach ($itemlist as $item){?>
                  <tr>
                    <td><?php echo $slno;?></td>
                    <td><?php echo $item['name'];?></td>
                    <td><?php echo $item['quantity'];?></td>
                    <td><?php echo $item['unitprice'];?></td>
                    <td><?php echo $item['tax'];?></td>
                    <?php $taxamt= ($item['unitprice']) * ($item['quantity']) * $item['tax'] /100 ;?>
                    <td><?php echo $taxamt;?></td>
                    <?php 
                     $total= ($item['unitprice']) * ($item['quantity'])+($taxamt) ;
                     $sum+= $total;
                    ?>
                    <td><?php echo $total;?></td>
                  </tr>
                  <?php 
                  $slno ++;} ?>
            
              </tbody>
              <tfoot class="font-weight-bold small">
                <td colspan="8"> 
                <span class="float-right">Total:<?php echo $sum?></span><br>
                <span class="float-right"><big>Grand Total:<?php echo $grandTotal?></big></span>
                </td>             
              </tfoot>
            </table>
          </div><!--table responsive end-->
          
          <br><p class="">Thank you for choosing our service.We look forward to meet you again</p>
             <p>Money once paid will not we refunded. However, it can be abjected towards any services</p>
             <p class="font-weight-bold small mt-0">Other T &C Apply</p>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>
