<html>
<!-------------script and css files-------------------->
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
<style>
.table>tbody>tr>td, .table>tfoot>tr>td{
    vertical-align: middle;
}
@media screen and (max-width: 600px) {
    table#cart tbody td .form-control{
    width:20%;
    display: inline !important;
  }
  .actions .btn{
    width:36%;
    margin:1.5em 0;
  }
  
  .actions .btn-info{
    float:left;
  }
  .actions .btn-danger{
    float:right;
  }
  
  table#cart thead { display: none; }
  table#cart tbody td { display: block; padding: .6rem; min-width:320px;}
  table#cart tbody tr td:first-child { background: #333; color: #fff; }
  table#cart tbody td:before {
    content: attr(data-th); font-weight: bold;
    display: inline-block; width: 8rem;
  }
  table#cart tfoot td{display:block; }
  table#cart tfoot td .btn{display:block;}
  
}
</style>

<!-- ----------------end of style------------- -->

<body>
<div class="container" id="result">
  <table id="cart" class="table table-hover table-condensed">
    <thead>
      <tr>
        <th style="width:10%">Product</th>
        <th style="width:10%">Quantity</th>
        <th style="width:8%">Unit price</th>
        <th style="width:10%">Net Amount</th>
        <th style="width:8%">Tax Rate(%)</th>
        <th style="width:8%">Tax Amount</th>
        <th style="width:22%" class="text-center">Amount</th>
        <th style="width:10%"></th>
      </tr>
    </thead>
    <tbody>
        <?php  
          foreach ($itemlist as $item){?>
            <tr>
              <td data-th="Product1"><?php echo $item['name'];?></td>
              <td data-th="Price"><?php echo $item['quantity'];?></td>
              <td data-th="Quantity"><?php echo $item['unitprice'];?></td>
              <td data-th="unitprice"><?php echo ($item['unitprice']) * ($item['quantity']) ;?></td>
              <td data-th="unitprice"><?php echo $item['tax'];?>%</td>
              <?php $taxamt= ($item['unitprice']) * ($item['quantity']) * $item['tax'] /100 ;?>
              <td data-th="Subtotal" class="text-center"><?php echo $taxamt ;?></td>
              <td data-th="Subtotal" class="text-center"><?php echo ($item['unitprice']) * ($item['quantity'])+($taxamt) ;?></td>
              <td class="actions" data-th="">
                <button class="btn btn-danger btn-sm" onclick="removeitem(<?php echo $item['c_id'] ;?>)"><i class="fa fa-trash-o"></i></button>                
              </td>
            </tr>
        <?php } ?>
    </tbody>
    <tfoot>
      <tr>   
        <td colspan="3" class="hidden-xs"></td>
        <td class="hidden-xs text-left"><strong>Total $<span id="total"></span></strong></td>
        <td colspan="2" class="hidden-xs"></td>
        <td class="hidden-xs text-center"><strong>Total $<span id="subtotal"></span></strong></td>
      </tr>
      <tr>
        <td colspan="7" class="text-right"><strong>Discount</strong>
          <select id="dropDownId" class="form-select">
            <option value="">--Select--</option>
            <option value="1">%</option>
            <option value="2">value</option>
          </select>
          <span id="discount"></span>
        </td>
      </tr>
      <tr>
        <td colspan="7" class="text-right"><strong><big><span id="grandtotal"></span></big></strong><br>
          <a class="btn btn-success btn" onclick="geneerateinvoice()">Generate Invoice <i class="fa fa-angle-right"></i></a>
        </td>
      </tr>
    </tfoot>
  </table>
</div>
</body>

<!-- -----------Scripts section ------------------ -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">

$(document).ready(function(){
  let result=0 ;
  let result2 =0 ;

  $('tbody tr').each(function(){
    var val =$(this).closest('tr').find('td:eq(3)').text()
    var val2 =$(this).closest('tr').find('td:eq(6)').text()
      if(val!='')
      {
          result += parseFloat(val);
      }
      if(val2!='')
      {
          result2 += parseFloat(val2);
      }

  });
    
  $('#total').append(result);
  $('#subtotal').append(result2.toFixed(2));

  $('select').on('change', function() {
      var discount_amt=0;
      var total_amt=$("#subtotal").text();
      if(this.value==1){
          discount_amt=(10*total_amt)/100;
          grandTotal=total_amt-discount_amt;
          $('#grandtotal').html("Grand Total :"+grandTotal);
      }else if(this.value==2){
         discount_amt=20;
         grandTotal=total_amt-discount_amt;
         $('#grandtotal').html("Grand Total :"+ grandTotal);
      }else{
         $('#grandtotal').html("");
      }
  });

});

// Function  to generate invoice 
  function geneerateinvoice()
  {
    var value=$('#dropDownId').val();
    if(value==""){
      alert("Please Apply Discount..!")
    }else{
       var myString=$("#grandtotal").text();
       var total_amt = myString.replace("Grand Total :",'');

            $.ajax({
                url: '<?php echo base_url();?>Billing',
                type: 'post',
                data: {amount:total_amt},
                dataType: 'json',
                success: function(responseData){
                    $('#result').html(responseData);
                }
            });

    }
  }

  //Function to remove an item from a cart
  function removeitem(id){
    $.ajax({
            url: '<?php echo base_url();?>Remove-item',
            type: 'post',
            data: {id:id},
            dataType: 'json',
            success: function(responseData){
              if(responseData.status==1){
                  location.reload();
                }else{
                  alert(responseData.msg);

                }
            }
    });
  }
  
</script>