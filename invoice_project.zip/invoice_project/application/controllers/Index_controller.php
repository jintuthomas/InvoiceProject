<?php 
class Index_controller extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library(array('session','form_validation'));
        $this->load->helper(array('form'));
	    $this->load->helper(array('url'));
//$this->load->model('registration_model');
		// $this->load->model('data_collection_model');
		 $this->load->model('invoicemodel',"invoicemdl");
	}
	/* Function to load item adding page*/ 

	public function index()
	{
		$this->load->view('additems');
	}

	/*function to vire the cart */

	public function itemview()
	{
		$data['itemlist']=$this->invoicemdl->get_cart_list();
		$this->load->view('itemview',$data);
	}
	
	/* function to add items */
	public function add()
	{

		$inputData = $this->input->post();
        $today   = date("Y-m-d H:i:s");        

		$res = [];
			foreach($inputData as $key1=> $inner) { 
			  foreach($inner as $key=>$val) { 
			    $res[$key][$key1] = $val; 
			  }
			}
			
		$res=$this->db->insert_batch('category',$res);
		if(isset($res))
          {
            $status=1;
            $msg="inserted successfully";
            
          }else{
              $status=2;
              $msg="Failed to insert";

          }
           echo json_encode(array('status' => $status, 'msg' => $msg));
          
	}
	/* Function to view Invoice page*/ 

	public function billing()
	{
		$inputData = $this->input->post();
		$data['grandTotal']=$inputData['amount'];
		$data['itemlist']=$this->invoicemdl->get_cart_list();
		$response=  $this->load->view('billingpage',$data,TRUE);
		echo json_encode($response);

	}

	/*Function to remove the cart item */ 

	public function remove_item()
	{
		$inputData   = $this->input->post();
		$category_id = $inputData['id'];
		$return=$this->invoicemdl->remove_item($category_id);
		if($return > 0 )
		{
			$status=1;
            $msg="Removed";

		}else{
			$status=0;
            $msg="Failed to remove the item";
		}
		echo json_encode(array('status' => $status, 'msg' => $msg));
		
	}

    
}

?>