<?php 
class invoicemodel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

     /*Function to get item from Db*/ 

    public function get_cart_list()
    {
        $query = "SELECT * FROM category 
                  WHERE  `status`='Y'";
            $result = $this->db->query($query);
            return $result->result_array();
    }   
    /* Function to remove items from list*/ 

    public function remove_item($id){
        $this->db->where("c_id",$id);
        return $this->db->update("category",array("status"=>'N'));
    }

}

?>